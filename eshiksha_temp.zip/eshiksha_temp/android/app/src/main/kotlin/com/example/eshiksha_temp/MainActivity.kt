package com.example.eshiksha_temp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
